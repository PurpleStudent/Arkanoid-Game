import java.awt.*;
import java.util.LinkedList;

public class TableOfBricks {

    public static void updateBricks(long now, Game game){
        long n= now-game.getLastTimeUpdateBricks();
        if (n>=30000){
            for (Brick brick: MainPanel.bricks) {
                brick.brickY= brick.brickY+Brick.brickHeight;
            }
            //for (int i = 0; i < 7; i++) {
                MainPanel.bricks.add(new GlassBrick(80, Brick.brickHeight + 50, Brick.brickWidth, Brick.brickHeight));
                MainPanel.bricks.add(new FlasherBrick(Brick.brickWidth + 80, Brick.brickHeight + 50, Brick.brickWidth, Brick.brickHeight));
                MainPanel.bricks.add(new PrizeBrick(2 * Brick.brickWidth + 80, Brick.brickHeight + 50, Brick.brickWidth, Brick.brickHeight));
                MainPanel.bricks.add(new InvisibleBrick(3 * Brick.brickWidth + 80, Brick.brickHeight + 50, Brick.brickWidth, Brick.brickHeight));
                MainPanel.bricks.add(new WoodenBrick(4 * Brick.brickWidth + 80, Brick.brickHeight + 50, Brick.brickWidth, Brick.brickHeight));
                MainPanel.bricks.add(new FlasherBrick(5 * Brick.brickWidth + 80, Brick.brickHeight + 50, Brick.brickWidth, Brick.brickHeight));
                MainPanel.bricks.add(new GlassBrick(6 * Brick.brickWidth + 80, Brick.brickHeight + 50, Brick.brickWidth, Brick.brickHeight));
            //}
            game.setNumberOfAllBricks(game.getNumberOfAllBricks()+7);
            game.setLastTimeUpdateBricks(System.currentTimeMillis());
        }
    }






    public static void draw(Graphics2D graphics2D){
        for (Brick brick: MainPanel.bricks) {
            if (brick.lives>0){
                brick.draw(graphics2D);
            }
        }
    }

}
