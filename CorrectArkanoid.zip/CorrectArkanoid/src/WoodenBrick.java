import java.awt.*;

public class WoodenBrick extends Brick{

    Color color= new Color(109, 34, 34, 191);


    WoodenBrick(int x, int y, int width, int height) {
        super(x, y, width, height);
    }


    @Override
    public int getLives() {
        return 2;
    }


    @Override
    public void draw(Graphics2D graphics2D) {
        graphics2D.setColor(new Color(109, 34, 34, 191));
        graphics2D.fillRect(brickX,brickY,brickWidth,brickHeight);

        graphics2D.setStroke(new BasicStroke(3));
        graphics2D.setColor(Color.MAGENTA);
        graphics2D.drawRect(brickX,brickY,brickWidth,brickHeight);
    }





    @Override
    boolean getWoodBrick() {
        return true;
    }
}
