import java.awt.*;

public class GlassBrick extends Brick{



    Color color= Color.CYAN;




    GlassBrick(int x, int y, int width, int height) {
        super(x, y, width, height);
    }






    @Override
    boolean getGlassBrick() {
        return true;
    }
}
