import java.awt.*;
import java.util.Collections;
import java.util.LinkedList;

public class Brick {
    public static int brickWidth= 77;
    public static int brickHeight= 50;
    public int brickX;
    public int brickY;

    public int lives;

    Color color= Color.CYAN;

    long id;

    Brick(int x, int y, int width, int height){
        this.brickX= x;
        this.brickY= y;
        lives= this.getLives();
        id= createNewId();
    }






    public Color getColor() {
        return color;
    }

    public long getId() {
        return id;
    }






    private long createNewId() {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Brick brick : MainPanel.bricks) { idList.add(brick.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        return n;
    }








    public void draw(Graphics2D graphics2D){
        graphics2D.setColor(Color.CYAN);
        graphics2D.fillRect(brickX,brickY,brickWidth,brickHeight);

        graphics2D.setStroke(new BasicStroke(3));
        graphics2D.setColor(Color.MAGENTA);
        graphics2D.drawRect(brickX,brickY,brickWidth,brickHeight);
    }




    public int getLives() {
        return 1;
    }
    Prize getPrize(){
        return null;
    }
    boolean getInvisible(){ return false; }















    boolean getFlasherBrick(){
        return false;
    }
    boolean getGlassBrick(){
        return false;
    }
    boolean getInvisibleBrick(){
        return false;
    }
    boolean getWoodBrick(){
        return false;
    }
    boolean getPrizeBrick(){
        return false;
    }

}
