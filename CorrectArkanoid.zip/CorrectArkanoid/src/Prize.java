import java.awt.*;
import java.util.HashMap;

public class Prize {

    public static int prizeWidth= 40;
    public static int prizeHeight= 40;
    public int prizeX;
    public int prizeY;

    boolean visible= false;
    String prizeType;

    HashMap<Integer,String> typesOfPrizes = new HashMap<>();




    Prize(int prizeX, int prizeY, int prizeType){
        typesOfPrizes.put(1,"fireball");
        typesOfPrizes.put(2,"multiple balls");
        typesOfPrizes.put(3,"big paddle");
        typesOfPrizes.put(4,"small paddle");
        typesOfPrizes.put(5,"fast ball");
        typesOfPrizes.put(6,"slow ball");
        typesOfPrizes.put(7,"dizzy paddle");
        typesOfPrizes.put(8,"random prize");
        this.prizeX= prizeX;
        this.prizeY= prizeY;
        this.prizeType= typesOfPrizes.get(prizeType);
    }




    public void draw(Graphics graphics){
        if (this.prizeType.equals("fireball")){
            graphics.setColor(new Color(46, 116, 89));
            graphics.fillRect(prizeX, prizeY, prizeWidth, prizeHeight);
        }
        if (this.prizeType.equals("multiple balls")){
            graphics.setColor(new Color(113, 213, 12));
            graphics.fillRect(prizeX, prizeY, prizeWidth, prizeHeight);
        }
        if (this.prizeType.equals("big paddle")){
            graphics.setColor(new Color(236, 199, 16));
            graphics.fillRect(prizeX, prizeY, prizeWidth, prizeHeight);
        }
        if (this.prizeType.equals("small paddle")){
            graphics.setColor(new Color(222, 124, 50));
            graphics.fillRect(prizeX, prizeY, prizeWidth, prizeHeight);
        }
        if (this.prizeType.equals("fast ball")){
            graphics.setColor(new Color(31, 133, 180));
            graphics.fillRect(prizeX, prizeY, prizeWidth, prizeHeight);
        }
        if (this.prizeType.equals("slow ball")){
            graphics.setColor(new Color(184, 97, 238));
            graphics.fillRect(prizeX, prizeY, prizeWidth, prizeHeight);
        }
        if (this.prizeType.equals("dizzy paddle")){
            graphics.setColor(new Color(145, 196, 212));
            graphics.fillRect(prizeX, prizeY, prizeWidth, prizeHeight);
        }
        if (this.prizeType.equals("random prize")) {
            graphics.setColor(new Color(189, 224, 64));
            graphics.fillRect(prizeX, prizeY, prizeWidth, prizeHeight);
        }
    }




}
