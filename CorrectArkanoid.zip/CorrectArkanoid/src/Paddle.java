import java.awt.*;

public class Paddle {
    public int paddleWidth= 77;
    public int paddleHeight= 50;
    public int paddleX;
    public int paddleY;

    boolean dizzyPaddle= false;





    Paddle(int paddleX, int paddleY, int paddleWidth, int paddleHeight){
        this.paddleX= paddleX;
        this.paddleY= paddleY;
        this.paddleWidth= paddleWidth;
        this.paddleHeight= paddleHeight;
    }






    public void draw(Graphics graphics){
        graphics.setColor(Color.GREEN);
        graphics.fillRect(paddleX, paddleY, paddleWidth, paddleHeight);
    }







    public double getMiddleOfPaddle(){
        return paddleX+(paddleWidth/2);
    }

}
