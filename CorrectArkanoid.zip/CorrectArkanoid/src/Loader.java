import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Objects;
import java.util.Scanner;

public class Loader {



    public static Ball loadBallFromFile(File file){
        try{
            if (file==null){return null;}
            else {
                Scanner scanner = new Scanner(file);
                int n = 1;
                double ballX = 0, ballY = 0, speedX = 0, speedY = 0;
                int radius = 0, lives = 0;
                boolean fireBall = false;
                while (scanner.hasNext() && n < 8) {
                    String s = scanner.nextLine();
                    if (n == 1) {
                        ballX = Double.parseDouble(s);
                    }
                    if (n == 2) {
                        ballY = Double.parseDouble(s);
                    }
                    if (n == 3) {
                        speedX = Double.parseDouble(s);
                    }
                    if (n == 4) {
                        speedY = Double.parseDouble(s);
                    }
                    if (n == 5) {
                        radius = Integer.parseInt(s);
                    }
                    if (n == 6) {
                        lives = Integer.parseInt(s);
                    }
                    if (n == 7) {
                        fireBall = s.equals("true");
                    }
                    n++;
                }
                scanner.close();

                Ball ball;
                if (fireBall) {
                    ball = new FireBall(ballX, ballY);
                    ball.speedX = speedX;
                    ball.speedY = speedY;
                    ball.radius = radius;
                    ball.lives = lives;
                } else {
                    ball = new Ball(ballX, ballY);
                    ball.speedX = speedX;
                    ball.speedY = speedY;
                    ball.radius = radius;
                    ball.lives = lives;
                }
                return ball;
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }





    public static Prize loadPrizeFromFile(File file){
        try{
            Scanner scanner = new Scanner(file);
            int n=1;

            int X = 0, Y = 0, Width = 0, Height = 0;
            int prizeType = 0;
            boolean visible= false;

            while (scanner.hasNext() && n<7) {
                String s = scanner.nextLine();

                if (n==1){X = Integer.parseInt(s);}
                if (n==2){Y = Integer.parseInt(s);}
                if (n==3){Width = Integer.parseInt(s);}
                if (n==4){Height = Integer.parseInt(s);}
                if (n==5){visible= s.equals("true");}
                if (n==6){prizeType=Integer.parseInt(s);}

                n++;
            }
            scanner.close();

            Prize prize= new Prize(X,Y,prizeType);

            prize.visible = visible;


            return prize;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }




























    public static Game loadGameFromFile(File file){
        try{
            Scanner scanner = new Scanner(file);
            int n=1;
            String userName="";
            int score=0, numberOfAllBricks=0;
            boolean play=false;
            long lastTimeUpdateBricks=0, id=0, lastTimeIncreaseBallSpeed=0, fireballActivationTime=0, bigPaddleActivationTime=0, smallPaddleActivationTime=0, dizzyPaddleActivationTime=0;
            while (scanner.hasNext() && n<12) {
                String s = scanner.nextLine();

                if (n==1){userName = s;}
                if (n==2){score = Integer.parseInt(s);}
                if (n==3){play = s.equals("true");}
                if (n==4){lastTimeUpdateBricks = Long.parseLong(s);}
                if (n==5){numberOfAllBricks=Integer.parseInt(s);}
                if (n==6){id=Long.parseLong(s);}
                if (n==7){lastTimeIncreaseBallSpeed=Long.parseLong(s);}

                if (n==8){fireballActivationTime=Long.parseLong(s);}
                if (n==9){bigPaddleActivationTime=Long.parseLong(s);}
                if (n==10){smallPaddleActivationTime=Long.parseLong(s);}
                if (n==11){dizzyPaddleActivationTime=Long.parseLong(s);}

                n++;
            }
            scanner.close();

            Game game= new Game(userName);

            game.setScore(score);
            game.setPlay(play);
            game.setLastTimeUpdateBricks(lastTimeUpdateBricks);
            game.setNumberOfAllBricks(numberOfAllBricks);
            game.setId(id);
            game.setLastTimeIncreaseBallSpeed(lastTimeIncreaseBallSpeed);

            game.setFireballActivationTime(fireballActivationTime);
            game.setBigPaddleActivationTime(bigPaddleActivationTime);
            game.setSmallPaddleActivationTime(smallPaddleActivationTime);
            game.setDizzyPaddleActivationTime(dizzyPaddleActivationTime);

            return game;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }










    public static void loadGames(){
        try {
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);

            for (File file : Objects.requireNonNull(resources.listFiles())) {
                for (File f : Objects.requireNonNull(file.listFiles())) {
                    if (f.getName().equals("game.txt")){
                        Game game= Loader.loadGameFromFile(f);
                        Game.games.add(game);
                    }
                }
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }







    public static Paddle loadPaddleFromFile(File file){
        try{
            Scanner scanner = new Scanner(file);
            int n=1;
            int paddleX=0, paddleY=0, paddleWidth=0, paddleHeight=0;
            boolean dizzyPaddle = false;

            while (scanner.hasNext() && n<6) {
                String s = scanner.nextLine();
                if (n==1){paddleX=Integer.parseInt(s);}
                if (n==2){paddleY=Integer.parseInt(s);}
                if (n==3){paddleWidth=Integer.parseInt(s);}
                if (n==4){paddleHeight=Integer.parseInt(s);}
                if (n==5){dizzyPaddle=s.equals("true");}
                n++;
            }
            scanner.close();

            Paddle paddle= new Paddle(paddleX,paddleY,paddleWidth,paddleHeight);

            paddle.dizzyPaddle= dizzyPaddle;

            return paddle;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }










    public static void loadBricks(Game game){
         try{
             String path = new File("").getAbsolutePath();
             String Path = path + "\\" + "resources\\";
             Files.createDirectories(Paths.get(Path));
             File resources = new File(Path);


             for (File file : Objects.requireNonNull(resources.listFiles())) {
                 if (Long.parseLong(file.getName())==game.getId()) {
                     for (File f : Objects.requireNonNull(file.listFiles())) {

                         if (f.getName().equals("Flasher Bricks")) {
                             for (File myFile : Objects.requireNonNull(f.listFiles())){
                                 FlasherBrick flasherBrick= Loader.loadFlasherBrickFromFile(myFile);
                                 MainPanel.bricks.add(flasherBrick);
                             }
                         }
                         if (f.getName().equals("Glass Bricks")){
                             for (File myFile : Objects.requireNonNull(f.listFiles())){
                                 GlassBrick glassBrick= Loader.loadGlassBrickFromFile(myFile);
                                 MainPanel.bricks.add(glassBrick);
                             }
                         }
                         if (f.getName().equals("Invisible Bricks")){
                             for (File myFile : Objects.requireNonNull(f.listFiles())){
                                 InvisibleBrick invisibleBrick= Loader.loadInvisibleBrickFromFile(myFile);
                                 MainPanel.bricks.add(invisibleBrick);
                             }
                         }
                         if (f.getName().equals("Prize Bricks")){
                             for (File myFile : Objects.requireNonNull(f.listFiles())){
                                 PrizeBrick prizeBrick= Loader.loadPrizeBrickFromFile(myFile);
                                 MainPanel.bricks.add(prizeBrick);
                             }
                         }
                         if (f.getName().equals("Wooden Bricks")){
                             for (File myFile : Objects.requireNonNull(f.listFiles())){
                                 WoodenBrick woodenBrick= Loader.loadWoodenBrickFromFile(myFile);
                                 MainPanel.bricks.add(woodenBrick);
                             }
                         }
                     }
                 }
             }
         }
         catch (IOException e) {
             e.printStackTrace();
         }
    }


















    public static File getPaddleFileWithGame(Game game){
        try {
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);

            File myFile=null;

            for (File file : Objects.requireNonNull(resources.listFiles())) {
                if (Long.parseLong(file.getName())==game.getId()) {
                    for (File f : Objects.requireNonNull(file.listFiles())) {
                        if (f.getName().equals("Paddle.txt")) {
                            myFile= f;
                            break;
                        }
                    }
                }
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }



    public static File getBallFileWithGame(Game game){
        try {
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);

            File myFile=null;

            for (File file : Objects.requireNonNull(resources.listFiles())) {
                if (Long.parseLong(file.getName())==game.getId()) {
                    for (File f : Objects.requireNonNull(file.listFiles())) {
                        if (f.getName().equals("Ball.txt")) {
                            myFile= f;
                            break;
                        }
                    }
                }
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }








    public static File getExtraBall1FileWithGame(Game game){
        try {
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);

            File myFile=null;

            for (File file : Objects.requireNonNull(resources.listFiles())) {
                if (Long.parseLong(file.getName())==game.getId()) {
                    for (File f : Objects.requireNonNull(file.listFiles())) {
                        if (f.getName().equals("extra Ball 1.txt")) {
                            myFile= f;
                            break;
                        }
                    }
                }
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }




    public static File getExtraBall2FileWithGame(Game game){
        try {
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);

            File myFile=null;

            for (File file : Objects.requireNonNull(resources.listFiles())) {
                if (Long.parseLong(file.getName())==game.getId()) {
                    for (File f : Objects.requireNonNull(file.listFiles())) {
                        if (f.getName().equals("extra Ball 2.txt")) {
                            myFile= f;
                            break;
                        }
                    }
                }
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }







































    public static FlasherBrick loadFlasherBrickFromFile(File file){
        try{
            Scanner scanner = new Scanner(file);
            int n=1, brickX=0, brickY=0, brickWidth=0, brickHeight=0, lives=0;
            long id=0;
            boolean invisible = false;
            while (scanner.hasNext() && n<8) {
                String s = scanner.nextLine();
                if (n==1){id=Long.parseLong(s);}
                if (n==2){brickX=Integer.parseInt(s);}
                if (n==3){brickY=Integer.parseInt(s);}
                if (n==4){brickWidth=Integer.parseInt(s);}
                if (n==5){brickHeight=Integer.parseInt(s);}
                if (n==6){lives=Integer.parseInt(s);}
                if (n==7){invisible = s.equals("true");}
                n++;
            }
            scanner.close();
            FlasherBrick flasherBrick = new FlasherBrick(brickX,brickY,brickWidth,brickHeight);;
            flasherBrick.id = id;
            flasherBrick.lives = lives;
            flasherBrick.invisible = invisible;
            return flasherBrick;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }


















    public static GlassBrick loadGlassBrickFromFile(File file){
        try{
            Scanner scanner = new Scanner(file);
            int n=1, brickX=0, brickY=0, brickWidth=0, brickHeight=0, lives=0;
            long id=0;
            boolean invisible = false;
            while (scanner.hasNext() && n<8) {
                String s = scanner.nextLine();
                if (n==1){id=Long.parseLong(s);}
                if (n==2){brickX=Integer.parseInt(s);}
                if (n==3){brickY=Integer.parseInt(s);}
                if (n==4){brickWidth=Integer.parseInt(s);}
                if (n==5){brickHeight=Integer.parseInt(s);}
                if (n==6){lives=Integer.parseInt(s);}
                if (n==7){invisible = s.equals("true");}
                n++;
            }
            scanner.close();
            GlassBrick glassBrick = new GlassBrick(brickX,brickY,brickWidth,brickHeight);;
            glassBrick.id = id;
            glassBrick.lives = lives;

            return glassBrick;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }















    public static InvisibleBrick loadInvisibleBrickFromFile(File file){
        try{
            Scanner scanner = new Scanner(file);
            int n=1, brickX=0, brickY=0, brickWidth=0, brickHeight=0, lives=0;
            long id=0;
            boolean invisible = false;
            while (scanner.hasNext() && n<8) {
                String s = scanner.nextLine();
                if (n==1){id=Long.parseLong(s);}
                if (n==2){brickX=Integer.parseInt(s);}
                if (n==3){brickY=Integer.parseInt(s);}
                if (n==4){brickWidth=Integer.parseInt(s);}
                if (n==5){brickHeight=Integer.parseInt(s);}
                if (n==6){lives=Integer.parseInt(s);}
                if (n==7){invisible = s.equals("true");}
                n++;
            }
            scanner.close();
            InvisibleBrick invisibleBrick = new InvisibleBrick(brickX,brickY,brickWidth,brickHeight);;
            invisibleBrick.id = id;
            invisibleBrick.lives = lives;

            return invisibleBrick;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
















    public static PrizeBrick loadPrizeBrickFromFile(File file){
        try{
            Scanner scanner = new Scanner(file);
            int n=1, brickX=0, brickY=0, brickWidth=0, brickHeight=0, lives=0;
            long id=0;
            boolean invisible = false;
            while (scanner.hasNext() && n<8) {
                String s = scanner.nextLine();
                if (n==1){id=Long.parseLong(s);}
                if (n==2){brickX=Integer.parseInt(s);}
                if (n==3){brickY=Integer.parseInt(s);}
                if (n==4){brickWidth=Integer.parseInt(s);}
                if (n==5){brickHeight=Integer.parseInt(s);}
                if (n==6){lives=Integer.parseInt(s);}
                if (n==7){invisible = s.equals("true");}
                n++;
            }
            scanner.close();
            PrizeBrick prizeBrick = new PrizeBrick(brickX,brickY,brickWidth,brickHeight);;
            prizeBrick.id = id;
            prizeBrick.lives = lives;

            return prizeBrick;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }

















    public static WoodenBrick loadWoodenBrickFromFile(File file){
        try{
            Scanner scanner = new Scanner(file);
            int n=1, brickX=0, brickY=0, brickWidth=0, brickHeight=0, lives=0;
            long id=0;
            boolean invisible = false;
            while (scanner.hasNext() && n<8) {
                String s = scanner.nextLine();
                if (n==1){id=Long.parseLong(s);}
                if (n==2){brickX=Integer.parseInt(s);}
                if (n==3){brickY=Integer.parseInt(s);}
                if (n==4){brickWidth=Integer.parseInt(s);}
                if (n==5){brickHeight=Integer.parseInt(s);}
                if (n==6){lives=Integer.parseInt(s);}
                if (n==7){invisible = s.equals("true");}
                n++;
            }
            scanner.close();
            WoodenBrick woodenBrick = new WoodenBrick(brickX,brickY,brickWidth,brickHeight);;
            woodenBrick.id = id;
            woodenBrick.lives = lives;

            return woodenBrick;
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return null;
    }
}
