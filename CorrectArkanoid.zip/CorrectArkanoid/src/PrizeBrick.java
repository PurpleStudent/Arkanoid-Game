import java.awt.*;
import java.util.Random;

public class PrizeBrick extends Brick{


    Color color= new Color(114, 89, 227, 191);
    Prize prize= new Prize(this.brickX,this.brickY,8);






    PrizeBrick(int x, int y, int width, int height) {
        super(x, y, width, height);
        Random random= new Random();
        int n= random.nextInt(8)+1 ;
        prize = new Prize(x,y,n);
    }






    @Override
    public void draw(Graphics2D graphics2D) {
        graphics2D.setColor(new Color(114, 89, 227, 191));
        graphics2D.fillRect(brickX,brickY,brickWidth,brickHeight);

        graphics2D.setStroke(new BasicStroke(3));
        graphics2D.setColor(Color.MAGENTA);
        graphics2D.drawRect(brickX,brickY,brickWidth,brickHeight);
    }






    @Override
    public Prize getPrize() {
        return prize;
    }






    @Override
    boolean getPrizeBrick() {
        return true;
    }








}
