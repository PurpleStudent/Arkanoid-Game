import java.awt.*;

public class Ball {
    double ballX = 120; // دابل کردم
    double ballY = 350; // دابل کردم

    double speedX = +1;
    double speedY = -1;

    int radius= 10;
    public int lives;






    Ball(double x,double y){
        this.ballX= x;
        this.ballY= y;
        this.lives= 3;
    }








    public void draw(Graphics graphics){
        graphics.setColor(Color.YELLOW);
        graphics.fillOval((int)ballX, (int)ballY, 20, 20);
    }






    public double getMiddleOfBall() {
        return ballX+radius;
    }



    public boolean getFireball(){
        return false;
    }
}










