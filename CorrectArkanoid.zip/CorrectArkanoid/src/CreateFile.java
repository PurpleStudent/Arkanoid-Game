import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Objects;

public class CreateFile {










    public static void createGameDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\"+id+"\\";
            Files.createDirectories(Paths.get(Path));
            File gameDirectory = new File(Path);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static File getGameDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);
            File myFile= null;
            for (File file : Objects.requireNonNull(resources.listFiles())) {
                if (file.getName().equals(String.valueOf(id))){
                    myFile= file;
                    break;
                }
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }




















    public static void createFlasherBricksDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\"+id+"\\Flasher Bricks\\";
            Files.createDirectories(Paths.get(Path));
            File flasherBricksDirectory = new File(Path);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static File getFlasherBricksDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);
            File myFile= null;
            for (File file : Objects.requireNonNull(resources.listFiles())) {
                if (file.getName().equals(String.valueOf(id))){
                    for (File f : Objects.requireNonNull(file.listFiles())){
                        if (f.getName().equals("Flasher Bricks")){myFile=f;}
                    }
                }
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

























    public static void createGlassBricksDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\"+id+"\\Glass Bricks\\";
            Files.createDirectories(Paths.get(Path));
            File glassBricksDirectory = new File(Path);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static File getGlassBricksDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);
            File myFile= null;
            for (File file : Objects.requireNonNull(resources.listFiles())) {
                if (file.getName().equals(String.valueOf(id))){
                    for (File f : Objects.requireNonNull(file.listFiles())){
                        if (f.getName().equals("Glass Bricks")){myFile=f;}
                    }
                }
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }



















    public static void createInvisibleBricksDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\"+id+"\\Invisible Bricks\\";
            Files.createDirectories(Paths.get(Path));
            File invisibleBricksDirectory = new File(Path);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static File getInvisibleBricksDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);
            File myFile= null;
            for (File file : Objects.requireNonNull(resources.listFiles())) {
                if (file.getName().equals(String.valueOf(id))){
                    for (File f : Objects.requireNonNull(file.listFiles())){
                        if (f.getName().equals("Invisible Bricks")){myFile=f;}
                    }
                }
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

























    public static void createPrizeBricksDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\"+id+"\\Prize Bricks\\";
            Files.createDirectories(Paths.get(Path));
            File prizeBricksDirectory = new File(Path);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static File getPrizeBricksDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);
            File myFile= null;
            for (File file : Objects.requireNonNull(resources.listFiles())) {
                if (file.getName().equals(String.valueOf(id))){
                    for (File f : Objects.requireNonNull(file.listFiles())){
                        if (f.getName().equals("Prize Bricks")){myFile=f;}
                    }
                }
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }


























    public static void createWoodenBricksDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\"+id+"\\Wooden Bricks\\";
            Files.createDirectories(Paths.get(Path));
            File woodenBricksDirectory = new File(Path);
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static File getWoodenBricksDirectory(long id){
        try{
            String path = new File("").getAbsolutePath();
            String Path = path + "\\" + "resources\\";
            Files.createDirectories(Paths.get(Path));
            File resources = new File(Path);
            File myFile= null;
            for (File file : Objects.requireNonNull(resources.listFiles())) {
                if (file.getName().equals(String.valueOf(id))){
                    for (File f : Objects.requireNonNull(file.listFiles())){
                        if (f.getName().equals("Wooden Bricks")){myFile=f;}
                    }
                }
            }
            return myFile;
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }



































    public static void createBallFile(Ball ball, File gameDirectory) {
        try {
            String ballPath = gameDirectory.getAbsolutePath() + "\\" + "Ball.txt";
            File ballFile = new File(ballPath);
            ballFile.getParentFile().mkdirs();
            if (!ballFile.exists()) {
                ballFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(ballFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(ball.ballX);
            out.println(ball.ballY);
            out.println(ball.speedX);
            out.println(ball.speedY);
            out.println(ball.radius);
            out.println(ball.lives);
            out.println(ball.getFireball());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }




    public static void createExtraBall1File(Ball extraBall1, File gameDirectory){
        try {
            if (extraBall1!=null) {
                String ballPath = gameDirectory.getAbsolutePath() + "\\" + "extra Ball 1.txt";
                File ballFile = new File(ballPath);
                ballFile.getParentFile().mkdirs();
                if (!ballFile.exists()) {
                    ballFile.createNewFile();
                }
                FileOutputStream fout = new FileOutputStream(ballFile, false);
                PrintStream out = new PrintStream(fout);

                out.println(extraBall1.ballX);
                out.println(extraBall1.ballY);
                out.println(extraBall1.speedX);
                out.println(extraBall1.speedY);
                out.println(extraBall1.radius);
                out.println(extraBall1.lives);
                out.println(extraBall1.getFireball());

                out.flush();
                out.close();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }


    public static void createExtraBall2File(Ball extraBall2, File gameDirectory){
        try {
            if (extraBall2!=null) {
                String ballPath = gameDirectory.getAbsolutePath() + "\\" + "extra Ball 2.txt";
                File ballFile = new File(ballPath);
                ballFile.getParentFile().mkdirs();
                if (!ballFile.exists()) {
                    ballFile.createNewFile();
                }
                FileOutputStream fout = new FileOutputStream(ballFile, false);
                PrintStream out = new PrintStream(fout);

                out.println(extraBall2.ballX);
                out.println(extraBall2.ballY);
                out.println(extraBall2.speedX);
                out.println(extraBall2.speedY);
                out.println(extraBall2.radius);
                out.println(extraBall2.lives);
                out.println(extraBall2.getFireball());

                out.flush();
                out.close();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }








    public static void createPrizeFile(Prize prize,PrizeBrick prizeBrick,File prizesDirectory){
        try {
            String brickPath = prizesDirectory.getAbsolutePath() + "\\" +prizeBrick.id+ ".txt";
            File brickFile = new File(brickPath);
            brickFile.getParentFile().mkdirs();
            if (!brickFile.exists()) {
                brickFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(brickFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(prize.prizeX);
            out.println(prize.prizeY);
            out.println(Prize.prizeWidth);
            out.println(Prize.prizeHeight);
            out.println(prize.visible);
            out.println(prize.prizeType);


            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }














    public static void createBrickFile(Brick brick,File bricksDirectory) {
        try {
            String brickPath = bricksDirectory.getAbsolutePath() + "\\" +brick.id+ ".txt";
            File brickFile = new File(brickPath);
            brickFile.getParentFile().mkdirs();
            if (!brickFile.exists()) {
                brickFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(brickFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(brick.id);
            out.println(brick.brickX);
            out.println(brick.brickY);
            out.println(Brick.brickWidth);
            out.println(Brick.brickHeight);
            out.println(brick.lives);
            out.println(brick.getInvisible());


            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }







































    public static void createPaddleFile(Paddle paddle, File gameDirectory) {
        try {
            String paddlePath = gameDirectory.getAbsolutePath() + "\\" + "Paddle.txt";
            File paddleFile = new File(paddlePath);
            paddleFile.getParentFile().mkdirs();
            if (!paddleFile.exists()) {
                paddleFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(paddleFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(paddle.paddleX);
            out.println(paddle.paddleY);
            out.println(paddle.paddleWidth);
            out.println(paddle.paddleHeight);
            out.println(paddle.dizzyPaddle);

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }








    public static void createGameFile(Game game, File gameDirectory){
        try{
            String gameStatePath = gameDirectory.getAbsolutePath() + "\\" + "game.txt";
            File paddleFile = new File(gameStatePath);
            paddleFile.getParentFile().mkdirs();
            if (!paddleFile.exists()) {
                paddleFile.createNewFile();
            }
            FileOutputStream fout = new FileOutputStream(paddleFile, false);
            PrintStream out = new PrintStream(fout);

            out.println(game.getUserName());
            out.println(game.getScore());
            out.println(game.isPlay());
            out.println(game.getLastTimeUpdateBricks());
            out.println(game.getNumberOfAllBricks());
            out.println(game.getId());
            out.println(game.getLastTimeIncreaseBallSpeed());

            out.println(game.getFireballActivationTime());
            out.println(game.getBigPaddleActivationTime());
            out.println(game.getSmallPaddleActivationTime());
            out.println(game.getDizzyPaddleActivationTime());

            out.flush();
            out.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }







































    public static void updatePreviousGameFile(MainPanel mainPanel){
        CreateFile.createGameFile(mainPanel.game, Objects.requireNonNull(CreateFile.getGameDirectory(mainPanel.game.getId())));
        CreateFile.createBallFile(mainPanel.ball, Objects.requireNonNull(CreateFile.getGameDirectory(mainPanel.game.getId())));
        CreateFile.createExtraBall1File(mainPanel.extraBall1, CreateFile.getGameDirectory(mainPanel.game.getId()));
        CreateFile.createExtraBall2File(mainPanel.extraBall2, CreateFile.getGameDirectory(mainPanel.game.getId()));
        for (Brick brick : MainPanel.bricks) {
            if (brick.getFlasherBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getFlasherBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getGlassBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getGlassBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getInvisibleBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getInvisibleBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getPrizeBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getPrizeBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getWoodBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getWoodenBricksDirectory(mainPanel.game.getId())));
            }
        }
        CreateFile.createPaddleFile(mainPanel.paddle, Objects.requireNonNull(CreateFile.getGameDirectory(mainPanel.game.getId())));
    }











    public static void savePreviousGameAsNewGame(MainPanel mainPanel){
        Game game= new Game(mainPanel.game.getUserName());

        game.setScore(mainPanel.game.getScore());
        game.setNumberOfAllBricks(mainPanel.game.getNumberOfAllBricks());
        game.setLastTimeUpdateBricks(mainPanel.game.getLastTimeUpdateBricks());
        game.setPlay(mainPanel.game.isPlay());

        mainPanel.game = game;

        CreateFile.createGameDirectory(mainPanel.game.getId());
        CreateFile.createFlasherBricksDirectory(mainPanel.game.getId());
        CreateFile.createGlassBricksDirectory(mainPanel.game.getId());
        CreateFile.createInvisibleBricksDirectory(mainPanel.game.getId());
        CreateFile.createPrizeBricksDirectory(mainPanel.game.getId());
        CreateFile.createWoodenBricksDirectory(mainPanel.game.getId());

        CreateFile.createGameFile(mainPanel.game, Objects.requireNonNull(CreateFile.getGameDirectory(mainPanel.game.getId())));
        CreateFile.createBallFile(mainPanel.ball, Objects.requireNonNull(CreateFile.getGameDirectory(mainPanel.game.getId())));
        CreateFile.createExtraBall1File(mainPanel.extraBall1, CreateFile.getGameDirectory(mainPanel.game.getId()));
        CreateFile.createExtraBall2File(mainPanel.extraBall2, CreateFile.getGameDirectory(mainPanel.game.getId()));
        for (Brick brick : MainPanel.bricks) {
            if (brick.getFlasherBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getFlasherBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getGlassBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getGlassBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getInvisibleBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getInvisibleBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getPrizeBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getPrizeBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getWoodBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getWoodenBricksDirectory(mainPanel.game.getId())));
            }
        }
        CreateFile.createPaddleFile(mainPanel.paddle, Objects.requireNonNull(CreateFile.getGameDirectory(mainPanel.game.getId())));

    }
















    public static void saveNewGame(MainPanel mainPanel){
        CreateFile.createGameDirectory(mainPanel.game.getId());
        CreateFile.createFlasherBricksDirectory(mainPanel.game.getId());
        CreateFile.createGlassBricksDirectory(mainPanel.game.getId());
        CreateFile.createInvisibleBricksDirectory(mainPanel.game.getId());
        CreateFile.createPrizeBricksDirectory(mainPanel.game.getId());
        CreateFile.createWoodenBricksDirectory(mainPanel.game.getId());

        CreateFile.createGameFile(mainPanel.game, Objects.requireNonNull(CreateFile.getGameDirectory(mainPanel.game.getId())));
        CreateFile.createBallFile(mainPanel.ball, Objects.requireNonNull(CreateFile.getGameDirectory(mainPanel.game.getId())));
        CreateFile.createExtraBall1File(mainPanel.extraBall1, CreateFile.getGameDirectory(mainPanel.game.getId()));
        CreateFile.createExtraBall2File(mainPanel.extraBall2, CreateFile.getGameDirectory(mainPanel.game.getId()));
        for (Brick brick : MainPanel.bricks) {
            if (brick.getFlasherBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getFlasherBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getGlassBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getGlassBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getInvisibleBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getInvisibleBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getPrizeBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getPrizeBricksDirectory(mainPanel.game.getId())));
            }
            if (brick.getWoodBrick()) {
                CreateFile.createBrickFile(brick, Objects.requireNonNull(CreateFile.getWoodenBricksDirectory(mainPanel.game.getId())));
            }
        }
        CreateFile.createPaddleFile(mainPanel.paddle, Objects.requireNonNull(CreateFile.getGameDirectory(mainPanel.game.getId())));

    }
}
