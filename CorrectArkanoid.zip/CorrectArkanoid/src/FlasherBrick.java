import java.awt.*;

public class FlasherBrick extends Brick{
    long firstTimeDraw= 0;
    boolean invisible;




    FlasherBrick(int x, int y, int width, int height) {
        super(x, y, width, height);
    }



















    @Override
    public void draw(Graphics2D graphics2D) {
        long n= (System.currentTimeMillis()-firstTimeDraw)/3000;
        if (n%2==0) {
            graphics2D.setColor(Color.MAGENTA);
            invisible=true;
            graphics2D.fillRect(brickX, brickY, brickWidth, brickHeight);

            graphics2D.setStroke(new BasicStroke(3));
            graphics2D.setColor(Color.MAGENTA);
            graphics2D.drawRect(brickX, brickY, brickWidth, brickHeight);
        }
        else {
            graphics2D.setColor(new Color(228, 150, 231));
            invisible=false;
            graphics2D.fillRect(brickX, brickY, brickWidth, brickHeight);

            graphics2D.setStroke(new BasicStroke(3));
            graphics2D.setColor(Color.MAGENTA);
            graphics2D.drawRect(brickX, brickY, brickWidth, brickHeight);
        }
    }





















    @Override
    boolean getInvisible() {
        return invisible;
    }





    @Override
    boolean getFlasherBrick() {
        return true;
    }
}
