import java.util.Collections;
import java.util.LinkedList;

public class Game {
    static LinkedList<Game> games= new LinkedList<>();

    private long id;
    private String userName;
    private int score = 0;
    private boolean play = false;  //static
    private long lastTimeUpdateBricks;  //static
    private int numberOfAllBricks; //static
    private long lastTimeIncreaseBallSpeed=0;

    private long fireballActivationTime;
    private long bigPaddleActivationTime;
    private long smallPaddleActivationTime;
    private long dizzyPaddleActivationTime;






    Game(String userName){
        this.userName = userName;
        this.id = createNewId();
    }









    private long createNewId() {
        long n = 1;
        LinkedList<Long> idList=new LinkedList<>();
        for (Game game : games) { idList.add(game.getId()); }
        if (idList.size()>0){n= Collections.max(idList)+1;}
        return n;
    }



















    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public boolean isPlay() {
        return play;
    }

    public void setPlay(boolean play) {
        this.play = play;
    }

    public long getLastTimeUpdateBricks() {
        return lastTimeUpdateBricks;
    }

    public void setLastTimeUpdateBricks(long lastTimeUpdateBricks) {
        this.lastTimeUpdateBricks = lastTimeUpdateBricks;
    }

    public int getNumberOfAllBricks() {
        return numberOfAllBricks;
    }

    public void setNumberOfAllBricks(int numberOfAllBricks) {
        this.numberOfAllBricks = numberOfAllBricks;
    }

    public long getLastTimeIncreaseBallSpeed() {return lastTimeIncreaseBallSpeed;}

    public void setLastTimeIncreaseBallSpeed(long lastTimeIncreaseBallSpeed) {this.lastTimeIncreaseBallSpeed = lastTimeIncreaseBallSpeed;}

    public long getFireballActivationTime() {return fireballActivationTime;}

    public void setFireballActivationTime(long fireballActivationTime) {this.fireballActivationTime = fireballActivationTime;}

    public long getBigPaddleActivationTime() {return bigPaddleActivationTime;}

    public void setBigPaddleActivationTime(long bigPaddleActivationTime) {this.bigPaddleActivationTime = bigPaddleActivationTime;}

    public long getSmallPaddleActivationTime() {return smallPaddleActivationTime;}

    public void setSmallPaddleActivationTime(long smallPaddleActivationTime) {this.smallPaddleActivationTime = smallPaddleActivationTime;}

    public long getDizzyPaddleActivationTime() {return dizzyPaddleActivationTime;}

    public void setDizzyPaddleActivationTime(long dizzyPaddleActivationTime) {this.dizzyPaddleActivationTime = dizzyPaddleActivationTime;}
}
