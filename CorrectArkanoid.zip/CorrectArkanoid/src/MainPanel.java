import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.LinkedList;
import java.util.Random;

public class MainPanel extends JPanel implements KeyListener,ActionListener {

    Game game;

    static LinkedList<Brick> bricks= new LinkedList<>();
    private final Timer timer;
    private int delay = 8;

    Paddle paddle= new Paddle(310, 540, 100, 8);

    Ball ball= new Ball(350,520);
    Ball extraBall1;
    Ball extraBall2;











    MainPanel(String name){  //آرگومان اضافه کردم
        this.game= new Game(name);

        addKeyListener(this);
        setFocusable(true); //true
        setFocusTraversalKeysEnabled(false); //false
        this.requestFocus();
        timer = new Timer(delay, this);
        timer.start();
    }









    public void setGame(Game game) {
        this.game = game;
    }








    public void paint(Graphics graphics){
        // پس زمینه
        graphics.setColor(Color.MAGENTA);
        graphics.fillRect(1, 1, 692, 592);

        // آجر ها
        TableOfBricks.updateBricks(System.currentTimeMillis(),game);
        TableOfBricks.draw((Graphics2D) graphics);

        graphics.setColor(Color.CYAN);
        graphics.fillRect(0, 0, 3, 592);
        graphics.fillRect(0, 0, 692, 3);
        graphics.fillRect(679, 0, 3, 592);  //x=691

        //paddle
        paddle.draw(graphics);

        // توپ
        ball.draw(graphics);

        //توپ اضافی1
        if (extraBall1!=null){
            extraBall1.draw(graphics);
        }

        //توپ اضافی2
        if (extraBall2!=null){
            extraBall2.draw(graphics);
        }

        //جایزه ها
        for (Brick brick:bricks) {
            if (brick.getPrize()!=null) {
                if (brick.getPrize().visible) {
                    brick.getPrize().draw(graphics);
                }
            }
        }

        //scores
        int highestScoreEver=0;
        for (Game game: Game.games) {
            if (game.getScore()>highestScoreEver){highestScoreEver=game.getScore();}
        }
        graphics.setColor(Color.BLUE);
        graphics.setFont(new Font("serif",Font.BOLD,25));
        graphics.drawString("my score : "+game.getScore()+"        ;        highest score ever : "+highestScoreEver,10,30);  //x=590


        //list scores
        int n=1;
        for (Game game: Game.games) {
            if (n==1) {
                graphics.setColor(Color.BLUE);
                graphics.setFont(new Font("serif", Font.BOLD, 25));
                graphics.drawString("some players :    "+game.getUserName() + " : "+game.getScore()+" , ", 10, 70);
                n = n + 1;
            }
            if (n==2) {
                graphics.setColor(Color.BLUE);
                graphics.setFont(new Font("serif", Font.BOLD, 25));
                graphics.drawString(game.getUserName() + " : "+game.getScore()+" , ...", 350, 70);
                n = n + 1;
            }
            if (n>2){break;}
        }





        if (ball.ballY>550){
            if (ball.lives==0) {
                game.setPlay(false);
                ball.speedX = 0;
                ball.speedY = 0;
                graphics.setColor(Color.BLUE);

                graphics.setFont(new Font("serif", Font.BOLD, 30));
                graphics.drawString("Game Over, scores: " + game.getScore(), 190, 300);

                graphics.setFont(new Font("serif", Font.BOLD, 20));
                graphics.drawString("Press the restart button.", 230, 350);
            }
        }


        if (game.getNumberOfAllBricks()<=0){
            game.setPlay(false);
            ball.speedX=0;
            ball.speedY=0;
            graphics.setColor(Color.BLUE);

            graphics.setFont(new Font("serif",Font.BOLD,30));
            graphics.drawString("You won, scores: "+game.getScore(),260,300);

            graphics.setFont(new Font("serif",Font.BOLD,20));
            graphics.drawString("Press the restart button.",230,350);
        }


        for (Brick brick: bricks){
            if (brick.brickY+Brick.brickHeight>570){
                if (brick.lives>0) {
                    game.setPlay(false);
                    ball.speedX = 0;
                    ball.speedY = 0;
                    graphics.setColor(Color.BLUE);

                    graphics.setFont(new Font("serif", Font.BOLD, 30));
                    graphics.drawString("Game Over, scores: " + game.getScore(), 190, 300);

                    graphics.setFont(new Font("serif", Font.BOLD, 20));
                    graphics.drawString("Press the restart button.", 230, 350);
                    break;
                }
            }
        }



        graphics.dispose();
    }























    @Override
    public void actionPerformed(ActionEvent e) {
        timer.start();

        if (game.isPlay()) {

            ball.ballX += ball.speedX;
            ball.ballY += ball.speedY;

            if (extraBall1!=null){
                extraBall1.ballX += extraBall1.speedX;
                extraBall1.ballY += extraBall1.speedY;
            }

            if (extraBall2!=null){
                extraBall2.ballX += extraBall2.speedX;
                extraBall2.ballY += extraBall2.speedY;
            }

            if (new Rectangle((int)ball.ballX, (int)ball.ballY, 20, 20).intersects(new Rectangle(paddle.paddleX, paddle.paddleY, paddle.paddleWidth, paddle.paddleHeight))) {
                double squareSpeed= (ball.speedX*ball.speedX) + (ball.speedY*ball.speedY);
                double speed= Math.pow(squareSpeed, 0.5);
                double n= Math.abs(ball.getMiddleOfBall()-paddle.getMiddleOfPaddle())/(paddle.paddleWidth);
                //ball.speedY = -ball.speedY;
                if (ball.speedY>0) {ball.speedY = -Math.pow(1-(1-n)*(1-n),0.5)*speed;}
                else {ball.speedY = Math.pow(1-(1-n)*(1-n),0.5)*speed;}
                if (ball.speedX>0) {ball.speedX = (1-n)*speed;}
                else {ball.speedX = -(1-n)*speed;}
            }

            if (extraBall1!=null){
                if (new Rectangle((int)extraBall1.ballX,(int)extraBall1.ballY,20,20).intersects(new Rectangle(paddle.paddleX, paddle.paddleY, paddle.paddleWidth, paddle.paddleHeight))){
                    double squareSpeed= (extraBall1.speedX*extraBall1.speedX) + (extraBall1.speedY*extraBall1.speedY);
                    double speed= Math.pow(squareSpeed, 0.5);
                    double n= Math.abs(extraBall1.getMiddleOfBall()-paddle.getMiddleOfPaddle())/paddle.paddleWidth;
                    //extraBall1.speedY = -extraBall1.speedY;
                    if (extraBall1.speedY>0) {extraBall1.speedY = -Math.pow(1-(1-n)*(1-n),0.5)*speed;}
                    else {extraBall1.speedY = Math.pow(1-(1-n)*(1-n),0.5)*speed;}
                    if (extraBall1.speedX>0) {extraBall1.speedX = (1-n)*speed;}
                    else {extraBall1.speedX = -(1-n)*speed;}
                }
            }

            if (extraBall2!=null){
                if (new Rectangle((int)extraBall2.ballX,(int)extraBall2.ballY,20,20).intersects(new Rectangle(paddle.paddleX, paddle.paddleY, paddle.paddleWidth, paddle.paddleHeight))){
                    double squareSpeed= (extraBall2.speedX*extraBall2.speedX) + (extraBall2.speedY*extraBall2.speedY);
                    double speed= Math.pow(squareSpeed, 0.5);
                    double n= Math.abs(extraBall2.getMiddleOfBall()-paddle.getMiddleOfPaddle())/paddle.paddleWidth;
                    //extraBall2.speedY = -extraBall2.speedY;
                    if (extraBall2.speedY>0) {extraBall2.speedY = -Math.pow(1-(1-n)*(1-n),0.5)*speed;}
                    else {extraBall2.speedY = Math.pow(1-(1-n)*(1-n),0.5)*speed;}
                    if (extraBall2.speedX>0) {extraBall2.speedX = (1-n)*speed;}
                    else {extraBall2.speedX = -(1-n)*speed;}
                }
            }

            for (Brick brick : bricks) {
                if (brick.lives > 0) {
                    int brickX = brick.brickX;
                    int brickY = brick.brickY;
                    int brickWidth = Brick.brickWidth;
                    int brickHeight = Brick.brickHeight;

                    Rectangle rectangle = new Rectangle(brickX, brickY, brickWidth, brickHeight);
                    Rectangle myBall = new Rectangle((int)ball.ballX, (int)ball.ballY, 20, 20);
                    if (myBall.intersects(rectangle)) {
                        intersectBallAndBrick(brick,ball,rectangle);
                    }

                    if (extraBall1 != null) {
                        Rectangle ball1= new Rectangle((int)extraBall1.ballX,(int)extraBall1.ballY,20,20);
                        if (ball1.intersects(rectangle)){
                            intersectBallAndBrick(brick,extraBall1,rectangle);
                        }
                    }

                    if (extraBall2 != null) {
                        Rectangle ball2= new Rectangle((int)extraBall2.ballX,(int)extraBall2.ballY,20,20);
                        if (ball2.intersects(rectangle)){
                            intersectBallAndBrick(brick,extraBall2,rectangle);
                        }
                    }

                }
            }



            for (Brick brick : bricks) {  //اضافه کردم
                if (brick.getPrize()!=null) {
                    Rectangle myPaddle = new Rectangle(paddle.paddleX, paddle.paddleY, paddle.paddleWidth, paddle.paddleHeight);
                    Rectangle myPrize = new Rectangle(brick.getPrize().prizeX,brick.getPrize().prizeY,Prize.prizeWidth,Prize.prizeHeight);
                    if (myPaddle.intersects(myPrize)){
                        usePrize(brick);
                    }
                }
            }


            for (Brick brick: bricks) {   // اضافه کردم
                if (brick.getPrize()!=null){
                    if (brick.getPrize().visible){
                        brick.getPrize().prizeY= brick.getPrize().prizeY+1;
                    }
                }
            }

            //ball.ballX += ball.speedX;
            //ball.ballY += ball.speedY;

            if (ball.ballX < 0) {
                ball.speedX = -ball.speedX;
            }
            if (ball.ballY < 0) {
                ball.speedY = -ball.speedY;
            }
            if (ball.ballX > 659) {
                ball.speedX = -ball.speedX;
            }
            if (ball.ballY > 550) {
                ball.lives = ball.lives-1;
                if (ball.lives>0) {
                    ball.speedY = -ball.speedY;
                }
            }

            if (extraBall1!=null){
                if (extraBall1.ballX<0){extraBall1.speedX= -extraBall1.speedX;}
                if (extraBall1.ballY<0){extraBall1.speedY= -extraBall1.speedY;}
                if (extraBall1.ballX>659){extraBall1.speedX= -extraBall1.speedX;}
                if (extraBall1.ballY > 550){
                    extraBall1.lives = extraBall1.lives-1;
                    if (extraBall1.lives>0){extraBall1.speedY = -extraBall1.speedY;}
                }
            }
            if (extraBall2!=null){
                if (extraBall2.ballX<0){extraBall2.speedX= -extraBall2.speedX;}
                if (extraBall2.ballY<0){extraBall2.speedY= -extraBall2.speedY;}
                if (extraBall2.ballX>659){extraBall2.speedX= -extraBall2.speedX;}
                if (extraBall2.ballY > 550){
                    extraBall2.lives = extraBall2.lives-1;
                    if (extraBall2.lives>0){extraBall2.speedY = -extraBall2.speedY;}
                }
            }


            if (ball.getFireball()){
                if (System.currentTimeMillis()-game.getFireballActivationTime()>10000){
                    int lives = ball.lives;  double sx = ball.speedX;  double sy = ball.speedY;
                    ball= new Ball(ball.ballX,ball.ballY);
                    ball.lives = lives;
                    ball.speedX= sx; ball.speedY= sy;
                }
            }

            if (paddle.paddleWidth==150){
                if (System.currentTimeMillis()-game.getBigPaddleActivationTime()>10000){
                    paddle.paddleWidth=100;
                }
            }

            if (paddle.paddleWidth==50){
                if (System.currentTimeMillis()-game.getSmallPaddleActivationTime()>10000){
                    paddle.paddleWidth=100;
                }
            }

            if (paddle.dizzyPaddle){
                if (System.currentTimeMillis()-game.getDizzyPaddleActivationTime()>10000){
                    paddle.dizzyPaddle=false;
                }
            }



            if (System.currentTimeMillis()-game.getLastTimeIncreaseBallSpeed()>5000){
                ball.speedX = 1.009*ball.speedX;
                ball.speedY = 1.009*ball.speedY;
                game.setLastTimeIncreaseBallSpeed(System.currentTimeMillis());
            }
        }
        repaint();
    }














    @Override
    public void keyTyped(KeyEvent e) {

    }






















    @Override
    public void keyPressed(KeyEvent e) {

        /*if (e.getKeyCode() == KeyEvent.VK_ENTER){
            if (!game.isPlay()){
                game.setPlay(true);
                ball.ballX=120;
                ball.ballY=350;
                ball.speedX=1;
                ball.speedY=-1;
                ball.lives=3;
                paddle.paddleX=310;
                game.setScore(0);
                game.setNumberOfAllBricks(21);  //این اشتباه است
                TableOfBricks.updateBricks(System.currentTimeMillis(),game);

                repaint();
            }
        }*/

        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            if (!paddle.dizzyPaddle) {
                if (paddle.paddleX >= 680-paddle.paddleWidth) {
                    paddle.paddleX = 680-paddle.paddleWidth;
                } else {
                    moveRight();
                }
            }
            else {
                if (paddle.paddleX < 10) {
                    paddle.paddleX = 10;
                } else {
                    moveLeft();
                }
            }
        }

        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            if (!paddle.dizzyPaddle) {
                if (paddle.paddleX < 10) {
                    paddle.paddleX = 10;
                } else {
                    moveLeft();
                }
            }
            else {
                if (paddle.paddleX >= 680-paddle.paddleWidth) {
                    paddle.paddleX = 680-paddle.paddleWidth;
                } else {
                    moveRight();
                }
            }
        }
    }

















    @Override
    public void keyReleased(KeyEvent e) {

    }



















    public void moveRight () {
        if (game.isPlay()) {
            paddle.paddleX += 20;
        }
    }






















    public void moveLeft () {
        if (game.isPlay()) {
            paddle.paddleX -= 20;
        }
    }

























    public void usePrize(Brick brick){
        if (brick.getPrize().prizeType.equals("fireball")){
            int lives = ball.lives;  double sx = ball.speedX;  double sy = ball.speedY;
            ball= new FireBall(ball.ballX,ball.ballY);
            ball.lives = lives;
            ball.speedX= sx; ball.speedY= sy;
            game.setFireballActivationTime(System.currentTimeMillis());
        }
        if (brick.getPrize().prizeType.equals("multiple balls")){
            extraBall1= new Ball(paddle.paddleX, 520);
            extraBall2= new Ball(paddle.paddleX+paddle.paddleWidth-20, 520);
        }
        if (brick.getPrize().prizeType.equals("big paddle")){
            paddle.paddleWidth = 150;
            game.setBigPaddleActivationTime(System.currentTimeMillis());
        }
        if (brick.getPrize().prizeType.equals("small paddle")){
            paddle.paddleWidth = 50;
            game.setSmallPaddleActivationTime(System.currentTimeMillis());
        }
        if (brick.getPrize().prizeType.equals("fast ball")){
            if (ball.speedX>0){ball.speedX = +1.5;}
            else {ball.speedX = -1.5;}
            if (ball.speedY>0){ball.speedY = +1.5;}
            else {ball.speedY = -1.5;}
        }
        if (brick.getPrize().prizeType.equals("slow ball")){
            if (ball.speedX>0){ball.speedX = +0.5;}
            else {ball.speedX = -0.5;}
            if (ball.speedY>0){ball.speedY = +0.5;}
            else {ball.speedY = -0.5;}
        }
        if (brick.getPrize().prizeType.equals("dizzy paddle")){
            paddle.dizzyPaddle=true;
            game.setDizzyPaddleActivationTime(System.currentTimeMillis());
        }

        if (brick.getPrize().prizeType.equals("random prize")){
            Random random= new Random();
            int n= random.nextInt(7)+1 ;
            brick.getPrize().prizeType= brick.getPrize().typesOfPrizes.get(n);
            usePrize(brick);
        }
    }

































    public void intersectBallAndBrick(Brick brick,Ball ball, Rectangle brickRectangle){

        if (ball.getFireball()){
            if (!brick.getFlasherBrick()){
                brick.lives =0; game.setNumberOfAllBricks(game.getNumberOfAllBricks()-1); game.setScore(game.getScore()+5);
                if (brick.getPrize() != null) { brick.getPrize().visible = true; }
            }
            else {
                if (!brick.getInvisible()){
                    brick.lives =0; game.setNumberOfAllBricks(game.getNumberOfAllBricks()-1); game.setScore(game.getScore()+5);
                    if (brick.getPrize() != null) { brick.getPrize().visible = true; }
                }
            }
        }

        else {
            if (!brick.getFlasherBrick()) {
                brick.lives = brick.lives - 1;
                if (brick.lives == 0) { game.setNumberOfAllBricks(game.getNumberOfAllBricks()-1); game.setScore(game.getScore()+5); }
                if (brick.getPrize() != null) { brick.getPrize().visible = true; }
                if (ball.ballX + 19 <= brickRectangle.x || ball.ballX + 1 >= brickRectangle.x + brickRectangle.width) {
                    ball.speedX = -ball.speedX; System.out.println("چپ و راست");
                }
                else { ball.speedY = -ball.speedY; }
            }
            else {
                if (!brick.getInvisible()) {
                    brick.lives = brick.lives - 1;
                    if (brick.lives == 0) { game.setNumberOfAllBricks(game.getNumberOfAllBricks()-1); game.setScore(game.getScore()+5); }
                    if (brick.getPrize() != null) { brick.getPrize().visible = true; }
                    if (ball.ballX + 19 <= brickRectangle.x || ball.ballX + 1 >= brickRectangle.x + brickRectangle.width) {
                        ball.speedX = -ball.speedX; System.out.println("چپ و راست");
                    }
                    else { ball.speedY = -ball.speedY; }
                }
            }
            //break;  //حواست باشه اینو کامنت کردم
        }
    }
}
