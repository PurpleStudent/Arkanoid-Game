import java.awt.*;

public class FireBall extends Ball{


    FireBall(double x, double y) {
        super(x, y);
    }






    @Override
    public void draw(Graphics graphics) {
        graphics.setColor(Color.RED);
        graphics.fillOval((int)ballX, (int)ballY, 20, 20);
    }






    @Override
    public boolean getFireball() {
        return true;
    }
}
