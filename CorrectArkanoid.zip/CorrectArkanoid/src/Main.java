import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.util.LinkedList;

public class Main{

    public static void main(String[] args) {
        Loader.loadGames();

        JFrame startJFrame= new JFrame();
        startJFrame.setBounds(240,320,350,100);
        startJFrame.setTitle("enter your name :");
        startJFrame.setResizable(false);
        JPanel startJPanel= new JPanel();
        JTextArea startJTextArea = new JTextArea(1, 25);
        startJPanel.add(startJTextArea);
        startJFrame.add(startJPanel,BorderLayout.CENTER);

        JButton OK= new JButton("ok");
        OK.setFocusable(false);
        OK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name= startJTextArea.getText();
                LinkedList<Game> myGames=new LinkedList<>();
                for (Game game:Game.games) {
                    if (game.getUserName().equals(name)){myGames.add(game);}
                }
                if (myGames.size()==0){
                    newMainFrame(name);
                    startJFrame.setVisible(false);
                }
                else {
                    savedGamesFrame(myGames);
                    startJFrame.setVisible(false);
                }
            }
        });
        startJFrame.add(OK,BorderLayout.SOUTH);
        startJFrame.setVisible(true);

    }




























    public static void savedGamesFrame(LinkedList<Game> games){
        JFrame savedGamesFrame= new JFrame();
        savedGamesFrame.setBounds(240,320,600,100);
        savedGamesFrame.setTitle("You have saved "+ games.size() +" games.");
        savedGamesFrame.setResizable(false);
        JPanel savedGamesPanel= new JPanel();
        JTextArea startJTextArea = new JTextArea(1, 25);
        savedGamesPanel.add(startJTextArea);
        savedGamesFrame.add(savedGamesPanel,BorderLayout.CENTER);

        JToolBar toolbar = new JToolBar("Applications");

        JButton OK= new JButton("ok");
        OK.setFocusable(false);
        OK.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int n= Integer.parseInt(startJTextArea.getText());
                Game game= games.get(n-1);
                savedMainFrame(game);
                savedGamesFrame.setVisible(false);
            }
        });

        JButton newGame= new JButton("new game");
        newGame.setFocusable(false);
        newGame.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                newMainFrame(games.get(0).getUserName());
                savedGamesFrame.setVisible(false);
            }
        });

        toolbar.add(OK);
        toolbar.add(newGame);
        savedGamesFrame.add(toolbar,BorderLayout.SOUTH);
        savedGamesFrame.setVisible(true);
    }
























    public static void newMainFrame(String name){
        //GamePanel.gameStartTime= System.currentTimeMillis();
        JFrame jFrame= new JFrame();
        //GamePanel gamePanel= new GamePanel();
        MainPanel mainPanel= new MainPanel(name);

        jFrame.setBounds(10,10,700,640); //height=600
        jFrame.setTitle("Arkanoid");
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLayout(new BorderLayout());  //میتونی حذف کنی این قسمت رو
        //jFrame.add(gamePanel);
        jFrame.add(mainPanel, BorderLayout.CENTER);  // بوردر لیوت گذاشتم
        //mainPanel.requestFocus();
        JToolBar toolbar = new JToolBar("Applications");

        JButton jButton1= new JButton("play");  //اضافه کردم
        jButton1.setFocusable(false);
        jButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainPanel.game.setPlay(true);
            }
        });

        JButton jButton2= new JButton("pause");  //اضافه کردم
        jButton2.setFocusable(false);
        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainPanel.game.setPlay(false);
            }
        });

        JButton jButton3= new JButton("restart");  //اضافه کردم
        jButton3.setFocusable(false);
        jButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!mainPanel.game.isPlay()){
                    mainPanel.game.setPlay(true);
                    mainPanel.ball.ballX=350;
                    mainPanel.ball.ballY=520;
                    mainPanel.ball.speedX=1;
                    mainPanel.ball.speedY=-1;
                    mainPanel.ball.lives=3;
                    mainPanel.paddle.paddleX=310;
                    mainPanel.game.setScore(0);
                    //game.setNumberOfAllBricks(21);  //این اشتباه است
                    MainPanel.bricks.clear();
                    TableOfBricks.updateBricks(System.currentTimeMillis(),mainPanel.game);
                    //repaint();
                }
            }
        });

        JButton jButton4= new JButton("save");  //اضافه کردم
        jButton4.setFocusable(false);
        jButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame miniJFrame= new JFrame();
                miniJFrame.setBounds(240,320,300,100);
                miniJFrame.setTitle("save");
                miniJFrame.setResizable(false);
                JPanel jPanel= new JPanel();
                JTextArea jTextArea = new JTextArea(1, 25);
                jPanel.add(jTextArea);
                miniJFrame.add(jPanel,BorderLayout.CENTER);
                JButton ok= new JButton("ok");
                ok.setFocusable(false);
                ok.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        System.out.println(jTextArea.getText());
                        CreateFile.saveNewGame(mainPanel);
                        miniJFrame.setVisible(false);
                    }
                });
                miniJFrame.add(ok,BorderLayout.SOUTH);
                miniJFrame.setVisible(true);
            }
        });

        toolbar.add(jButton1);
        toolbar.add(jButton2);
        toolbar.add(jButton3);
        toolbar.add(jButton4);

        jFrame.add(toolbar, BorderLayout.SOUTH);

        jFrame.setVisible(true);
    }
































    public static void savedMainFrame(Game game){
        //GamePanel.gameStartTime= System.currentTimeMillis();

        JFrame jFrame= new JFrame();

        //GamePanel gamePanel= new GamePanel();
        MainPanel mainPanel= new MainPanel(game.getUserName());

        mainPanel.setGame(game);
        mainPanel.ball= Loader.loadBallFromFile(Loader.getBallFileWithGame(game));
        mainPanel.extraBall1= Loader.loadBallFromFile(Loader.getExtraBall1FileWithGame(game));
        mainPanel.extraBall2= Loader.loadBallFromFile(Loader.getExtraBall2FileWithGame(game));
        Loader.loadBricks(game);
        mainPanel.paddle= Loader.loadPaddleFromFile(Loader.getPaddleFileWithGame(game));

        jFrame.setBounds(10,10,700,640); //height=600
        jFrame.setTitle("Arkanoid");
        jFrame.setResizable(false);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLayout(new BorderLayout());  //میتونی حذف کنی این قسمت رو
        //jFrame.add(gamePanel);
        jFrame.add(mainPanel, BorderLayout.CENTER);  // بوردر لیوت گذاشتم
        //mainPanel.requestFocus();

        JToolBar toolbar = new JToolBar("Applications");

        JButton jButton1= new JButton("play");  //اضافه کردم
        jButton1.setFocusable(false);
        jButton1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainPanel.game.setPlay(true);
                System.out.println(mainPanel.game.isPlay());
            }
        });

        JButton jButton2= new JButton("pause");  //اضافه کردم
        jButton2.setFocusable(false);
        jButton2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mainPanel.game.setPlay(false);
            }
        });

        JButton jButton3= new JButton("restart");  //اضافه کردم
        jButton3.setFocusable(false);
        jButton3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!mainPanel.game.isPlay()){
                    mainPanel.game.setPlay(true);
                    mainPanel.ball.ballX=350;
                    mainPanel.ball.ballY=520;
                    mainPanel.ball.speedX=1;
                    mainPanel.ball.speedY=-1;
                    mainPanel.ball.lives=3;
                    mainPanel.paddle.paddleX=310;
                    mainPanel.game.setScore(0);
                    //game.setNumberOfAllBricks(21);  //این اشتباه است
                    MainPanel.bricks.clear();
                    TableOfBricks.updateBricks(System.currentTimeMillis(),mainPanel.game);
                    //repaint();
                }
            }
        });

        JButton jButton4= new JButton("save");  //اضافه کردم
        jButton4.setFocusable(false);
        jButton4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFrame miniJFrame= new JFrame();
                miniJFrame.setBounds(240,320,320,100);
                miniJFrame.setTitle("save");
                miniJFrame.setResizable(false);
                JPanel jPanel= new JPanel();
                /*JTextArea jTextArea = new JTextArea(1, 25);
                jPanel.add(jTextArea);
                miniJFrame.add(jPanel,BorderLayout.CENTER);*/
                JButton updateTheOldGame= new JButton("Update the old game.");
                updateTheOldGame.setFocusable(false);
                updateTheOldGame.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        //System.out.println(jTextArea.getText());
                        CreateFile.updatePreviousGameFile(mainPanel);
                        miniJFrame.setVisible(false);
                    }
                });
                miniJFrame.add(updateTheOldGame,BorderLayout.WEST);

                JButton saveThisGameAsNewGame= new JButton("Save as a new game.");
                saveThisGameAsNewGame.setFocusable(false);
                saveThisGameAsNewGame.addActionListener(new ActionListener() {
                    @Override
                    public void actionPerformed(ActionEvent e) {
                        //System.out.println(jTextArea.getText());
                        CreateFile.savePreviousGameAsNewGame(mainPanel);
                        miniJFrame.setVisible(false);
                    }
                });
                miniJFrame.add(saveThisGameAsNewGame,BorderLayout.EAST);

                miniJFrame.setVisible(true);
            }
        });

        toolbar.add(jButton1);
        toolbar.add(jButton2);
        toolbar.add(jButton3);
        toolbar.add(jButton4);

        jFrame.add(toolbar, BorderLayout.SOUTH);

        jFrame.setVisible(true);
    }
}
